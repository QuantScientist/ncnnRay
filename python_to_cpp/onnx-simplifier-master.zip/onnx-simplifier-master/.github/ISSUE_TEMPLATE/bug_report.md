---
name: Bug report
about: Create a report to help us improve
title: "[BUG] "
labels: ''
assignees: ''

---

**Describe the bug**
A clear and concise description of what the bug is.

**Model**
To reproduce the problem, please post download link of your model here, or send your model to daquexian566@gmail.com
